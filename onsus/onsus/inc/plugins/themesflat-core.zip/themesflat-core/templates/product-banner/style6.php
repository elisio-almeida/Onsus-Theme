<?php
   
?>
<div class=" item-banner">
    <div class="inner">
        <?php if ($settings['labeltext3'] != '' || $settings['label4'] != '') {?>
        <div class="label"><div class="text"><?php echo esc_attr($settings['labeltext3']); ?></div><?php echo esc_attr($settings['label4']); ?></div>
        <?php } ?>
        <h2 class="heading"><?php echo esc_attr($settings['heading6']); ?> </h2>
        <h2 class="heading big"><?php echo esc_attr($settings['heading62']); ?></h2>
    </div>
    
</div>