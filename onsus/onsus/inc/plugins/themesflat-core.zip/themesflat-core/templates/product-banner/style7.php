<?php

?>
<div class=" item-banner">
    <div class="inner">
        <h2 class="heading"><?php echo esc_attr($settings['heading7']); ?> </h2>
        <h2 class="heading big"><?php echo esc_attr($settings['heading72']); ?></h2>
        <p class="sub-heading"><?php echo esc_attr($settings['sub_heading3']); ?></p>
    </div>
</div>